package com.mfistudio.salealert

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Base64
import android.util.LruCache
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// UTILITY FUNCTIONS & SANITIZERS
// ==========================================

fun sanitizeUrl(inputUrl: String): String {
    if (inputUrl.isBlank()) return ""
    var trimmed = inputUrl.trim { it <= ' ' }
    trimmed = trimmed.replace(Regex("[\\n\\r\\t]"), "")
    if (trimmed.endsWith("/")) {
        trimmed = trimmed.removeSuffix("/")
    }
    if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        trimmed = "https://$trimmed"
    }
    return trimmed
}

fun isValidUrl(url: String): Boolean {
    if (url.isBlank()) return false
    val sanitized = sanitizeUrl(url)
    return Patterns.WEB_URL.matcher(sanitized).matches() || sanitized.startsWith("https://") || sanitized.startsWith("http://")
}

fun uriToBase64(context: Context, uri: Uri): String {
    try {
        val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
        val bitmap = BitmapFactory.decodeStream(inputStream)
        inputStream?.close()

        if (bitmap == null) return ""

        val maxSize = 600f
        val width = bitmap.width
        val height = bitmap.height
        val ratio = width.toFloat() / height.toFloat()
        val targetWidth: Int
        val targetHeight: Int
        if (ratio > 1) {
            targetWidth = maxSize.toInt()
            targetHeight = (maxSize / ratio).toInt()
        } else {
            targetHeight = maxSize.toInt()
            targetWidth = (maxSize * ratio).toInt()
        }

        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        val outputStream = ByteArrayOutputStream()
        resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 60, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    } catch (_: Exception) {
        return ""
    }
}

object BitmapCache {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8
    private val cache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    fun get(key: String): Bitmap? = cache.get(key)
    fun put(key: String, bitmap: Bitmap) {
        if (key.isNotBlank()) cache.put(key, bitmap)
    }
}

@Composable
fun rememberDecodedBitmap(base64Str: String): Bitmap? {
    var bitmap by remember(base64Str) { mutableStateOf<Bitmap?>(BitmapCache.get(base64Str)) }

    LaunchedEffect(base64Str) {
        if (base64Str.isNotBlank() && bitmap == null) {
            withContext(Dispatchers.IO) {
                val decoded = try {
                    val decodedBytes = Base64.decode(base64Str, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                } catch (_: Exception) {
                    null
                }
                if (decoded != null) {
                    BitmapCache.put(base64Str, decoded)
                    withContext(Dispatchers.Main) {
                        bitmap = decoded
                    }
                }
            }
        }
    }
    return bitmap
}

fun extractDomain(urlStr: String, shopName: String): String {
    if (urlStr.isNotBlank()) {
        try {
            val uri = Uri.parse(urlStr)
            val host = uri.host
            if (!host.isNullOrBlank()) {
                return host.removePrefix("www.")
            }
        } catch (_: Exception) {}
    }
    val cleanedShop = shopName.lowercase().replace(" ", "").replace(".", "").replace("'", "")
    return "$cleanedShop.com"
}

@Composable
fun rememberFaviconBitmap(domain: String): Bitmap? {
    val faviconUrl = "https://www.google.com/s2/favicons?domain=$domain&sz=128"
    var bitmap by remember(faviconUrl) { mutableStateOf<Bitmap?>(BitmapCache.get(faviconUrl)) }

    LaunchedEffect(faviconUrl) {
        if (domain.isNotBlank() && bitmap == null) {
            withContext(Dispatchers.IO) {
                try {
                    val client = OkHttpClient()
                    val request = Request.Builder().url(faviconUrl).build()
                    val response = client.newCall(request).execute()
                    if (response.isSuccessful) {
                        val stream = response.body?.byteStream()
                        if (stream != null) {
                            val decoded = BitmapFactory.decodeStream(stream)
                            if (decoded != null) {
                                BitmapCache.put(faviconUrl, decoded)
                                withContext(Dispatchers.Main) {
                                    bitmap = decoded
                                }
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }
    return bitmap
}

fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return r * c
}

fun getCityCoordinates(city: String): Pair<Double, Double> {
    return when (city.lowercase().trim()) {
        "sialkot" -> Pair(32.4945, 74.5229)
        "lahore" -> Pair(31.5204, 74.3587)
        "islamabad" -> Pair(33.6844, 73.0479)
        "karachi" -> Pair(24.8607, 67.0011)
        "faisalabad" -> Pair(31.4504, 73.1350)
        "rawalpindi" -> Pair(33.5651, 73.0169)
        "multan" -> Pair(30.1575, 71.5249)
        "gujranwala" -> Pair(32.1877, 74.1945)
        "peshawar" -> Pair(34.0151, 71.5249)
        "quetta" -> Pair(30.1798, 66.9750)
        else -> Pair(32.4945, 74.5229)
    }
}

fun getUserCountryCode(context: Context): String {
    return try {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val simCountry = tm?.simCountryIso?.uppercase()
        if (!simCountry.isNullOrBlank()) {
            simCountry
        } else {
            Locale.getDefault().country.uppercase().ifBlank { "PK" }
        }
    } catch (_: Exception) {
        Locale.getDefault().country.uppercase().ifBlank { "PK" }
    }
}

fun getCachedBrandDeals(context: Context): List<Deal>? {
    return try {
        val prefs = context.getSharedPreferences("brand_sales_cache", Context.MODE_PRIVATE)
        val timestamp = prefs.getLong("cache_time", 0L)
        val currentTime = System.currentTimeMillis()
        if (currentTime - timestamp < 12L * 60 * 60 * 1000L) {
            val jsonStr = prefs.getString("cache_deals", null)
            if (!jsonStr.isNullOrBlank()) {
                val jsonArray = JSONArray(jsonStr)
                val deals = mutableListOf<Deal>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    deals.add(
                        Deal(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            shopName = obj.optString("shopName", ""),
                            title = obj.optString("title", ""),
                            discount = obj.optInt("discount", 20),
                            category = obj.optString("category", "Clothes"),
                            city = obj.optString("city", "All"),
                            address = obj.optString("address", ""),
                            whatsappNumber = obj.optString("whatsappNumber", "923338705813"),
                            badge = obj.optString("badge", "HOT DEAL"),
                            url = obj.optString("url", "https://www.google.com"),
                            isBrand = true
                        )
                    )
                }
                if (deals.isNotEmpty()) return deals
            }
        }
        null
    } catch (_: Exception) {
        null
    }
}

fun saveBrandDealsToCache(context: Context, deals: List<Deal>) {
    try {
        val prefs = context.getSharedPreferences("brand_sales_cache", Context.MODE_PRIVATE)
        val jsonArray = JSONArray()
        for (deal in deals) {
            val obj = JSONObject().apply {
                put("id", deal.id)
                put("shopName", deal.shopName)
                put("title", deal.title)
                put("discount", deal.discount)
                put("category", deal.category)
                put("city", deal.city)
                put("address", deal.address)
                put("whatsappNumber", deal.whatsappNumber)
                put("badge", deal.badge)
                put("url", deal.url)
            }
            jsonArray.put(obj)
        }
        prefs.edit()
            .putString("cache_deals", jsonArray.toString())
            .putLong("cache_time", System.currentTimeMillis())
            .apply()
    } catch (_: Exception) {}
}

// ==========================================
// EXPANDED GOOGLE CUSTOM SEARCH API CLIENT
// ==========================================

fun getDynamicNationalBrandDeals(categoryFilter: String = "All", countryCode: String = "PK"): List<Deal> {
    val allBrandDeals = listOf(
        // Clothes (25+ Deals)
        Deal(shopName = "Alkaram Studio", title = "Festive Clearance Flat 50% Off Unstitched & Pret Collection", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://www.alkaramstudio.com", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Khaadi", title = "Winter Clearance Flat 50% Off on Fabric & Pret", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://pk.khaadi.com", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Sapphire", title = "Ready to Wear & Unstitched Flat 40% Off Intermix Sale", discount = 40, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://pk.sapphireonline.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "J. Junaid Jamshed", title = "Exclusive Fragrances, Lawn & Men's Apparel Sale", discount = 35, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://www.j.com.pk", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Gul Ahmed", title = "Ideas Great Winter Sale Flat 50% Off Everything", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://www.gulahmedshop.com", isBrand = true, badge = "HOT DEAL"),
        Deal(shopName = "Limelight", title = "Pret, Unstitched & Western Wear Flat 30% Discount", discount = 30, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://www.limelight.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Maria B", title = "Luxury Velvet & Chiffon Collection Special Discount", discount = 35, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://www.mariab.pk", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Outfitters", title = "Winter Apparel & Jackets Flat 40% Off Clearance Sale", discount = 40, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://outfitters.com.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Bonanza Satrangi", title = "Mid-Season Sale Flat 50% Off Unstitched & Beauty", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://bonanzasatrangi.com", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Nishat Linen", title = "Summer & Winter Stock Clearance Flat 30% Off", discount = 30, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://nishatlinen.com", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Sana Safinaz", title = "Muzlin & Silk Collection Flat 40% Off Discount", discount = 40, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://www.sanasafinaz.com", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Asim Jofa", title = "Festive Velvet & Lawn Collection Special Discount", discount = 35, category = "Clothes", city = "All", address = "Online Nationwide Shipping", url = "https://asimjofa.com", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Cross Stitch", title = "Printed & Embroidered Pret Flat 30% Off Offer", discount = 30, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://crossstitch.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Ethnic", title = "Fusion Wear & Unstitched Suits Flat 40% Clearance", discount = 40, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://ethnic.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Beechtree", title = "Western Wear & Pret Collection Flat 50% Off", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://beechtree.pk", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Generation", title = "Traditional Women Suits & Kurtis Special Offer", discount = 25, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://generation.com.pk", isBrand = true, badge = "25% OFF"),
        Deal(shopName = "Bareeze", title = "Classic Embroidered Lawn & Cotton Special Sale", discount = 30, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://www.bareeze.com", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Charcoal", title = "Suits, Blazers & Formal Shirts Flat 40% Off", discount = 40, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://charcoal.com.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Uniworth", title = "Men's Executive Dress Shirts & Shalwar Kameez Sale", discount = 35, category = "Clothes", city = "All", address = "Nationwide Stores & Online", url = "https://uniworthdress.com", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Royal Tag", title = "Men's Formal Suits & Jackets Flat 40% Off", discount = 40, category = "Clothes", city = "All", address = "Nationwide Outlets & Online", url = "https://royaltag.com.pk", isBrand = true, badge = "40% OFF"),

        // Food (25+ Deals)
        Deal(shopName = "KFC", title = "Zinger Stacker & Krunch Burger Mega Combo Deal!", discount = 30, category = "Food", city = "All", address = "Nationwide Outlets & App", url = "https://www.kfcpakistan.com", isBrand = true, badge = "HOT DEAL"),
        Deal(shopName = "Cheezious", title = "Cheezious Crown Crust & BOGO Pizza Extravaganza!", discount = 35, category = "Food", city = "All", address = "All Cheezious Outlets & App", url = "https://cheezious.com", isBrand = true, badge = "SPECIAL OFFER"),
        Deal(shopName = "McDonald's", title = "McValue Meal Deals & Spicy Zinger Chicken Offers", discount = 25, category = "Food", city = "All", address = "Nationwide Drive-Thru & App", url = "https://mcdonalds.com.pk", isBrand = true, badge = "BEST VALUE"),
        Deal(shopName = "Domino's Pizza", title = "Flat 50% Off on Medium & Large Pizzas Every Tuesday!", discount = 50, category = "Food", city = "All", address = "Nationwide Delivery & Outlets", url = "https://www.dominos.com.pk", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Pizza Hut", title = "Super Value Deal: Any 2 Large Pizzas Special Offer", discount = 40, category = "Food", city = "All", address = "Nationwide Outlets & Delivery", url = "https://www.pizzahut.com.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Subway", title = "Sub of the Day & Footlong Meal Combo Discounts", discount = 30, category = "Food", city = "All", address = "Nationwide Outlets", url = "https://subway.com.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Hardee's", title = "Famous Star Burger & Curly Fries Family Bundle", discount = 30, category = "Food", city = "All", address = "Nationwide Outlets & Delivery", url = "https://hardees.com.pk", isBrand = true, badge = "HOT DEAL"),
        Deal(shopName = "Broadway Pizza", title = "Slice of Happiness 20-Inch Giant Pizza Offer!", discount = 35, category = "Food", city = "All", address = "Nationwide Outlets & App", url = "https://broadwaypizza.com.pk", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Ranchers", title = "Cowboy Burgers & Loaded Fries Mega Feast", discount = 25, category = "Food", city = "All", address = "Outlets & App Delivery", url = "https://rancherscafe.com", isBrand = true, badge = "BURGER DEAL"),
        Deal(shopName = "OPTP", title = "Southern Fried Chicken & Garlic Mayo Fries Deal", discount = 20, category = "Food", city = "All", address = "Nationwide Outlets & Online", url = "https://optp.biz", isBrand = true, badge = "HOT OFFER"),
        Deal(shopName = "Gloria Jean's Coffees", title = "Handcrafted Hot & Cold Beverages Special Offer", discount = 20, category = "Food", city = "All", address = "Nationwide Outlets", url = "https://gloriajeanscoffees.com.pk", isBrand = true, badge = "COFFEE OFFER"),
        Deal(shopName = "Texas Chicken", title = "Crunchy Tenders & Biscuits Combo Discount", discount = 25, category = "Food", city = "All", address = "Nationwide Outlets & Delivery", url = "https://texaschickenpakistan.com", isBrand = true, badge = "25% OFF"),
        Deal(shopName = "Kababjees", title = "Bakers & Fried Chicken Mega Value Feast", discount = 30, category = "Food", city = "All", address = "Outlets & Delivery App", url = "https://kababjees.com", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Savour Foods", title = "Special Chicken Pulao & Shami Kabab Value Combo", discount = 20, category = "Food", city = "All", address = "Nationwide Branches", url = "https://savourfoods.com", isBrand = true, badge = "DESI DEAL"),
        Deal(shopName = "Layers Bakeshop", title = "Gourmet Cakes & Cupcakes Sweet Discount Offer", discount = 15, category = "Food", city = "All", address = "Nationwide Branches & App", url = "https://layers.pk", isBrand = true, badge = "SWEET OFFER"),

        // Shoes (20+ Deals)
        Deal(shopName = "Stylo", title = "Footwear & Handbags Flat 50% Off Clearance Sale", discount = 50, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://stylo.pk", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Servis", title = "Shoes for All Family Flat 40% Discount Sale", discount = 40, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://www.servis.pk", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Bata", title = "Bata Footwear Season End Clearance Flat 50% Off!", discount = 50, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://www.bata.pk", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Borjan", title = "Men & Women Leather Shoes & Accessories Flat 30% Off", discount = 30, category = "Shoes", city = "All", address = "Nationwide Outlets & Online", url = "https://borjan.com.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Ndure", title = "Casual, Sports & Formal Shoes Flat 40% Off Sale", discount = 40, category = "Shoes", city = "All", address = "Nationwide Outlets & Online", url = "https://www.ndure.com", isBrand = true, badge = "40% OFF"),
        Deal(shopName = "Metro Shoes", title = "Chic Chappals, Pumps & Heels Special Discount", discount = 30, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://metroshoes.com.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Hush Puppies", title = "Premium Comfort Leather Footwear Flat 25% Off", discount = 25, category = "Shoes", city = "All", address = "Nationwide Outlets & Online", url = "https://hushpuppies.com.pk", isBrand = true, badge = "PREMIUM DEAL"),
        Deal(shopName = "ECS (Shoe Planet)", title = "Bridal & Casual Footwear Clearance Flat 50% Off", discount = 50, category = "Shoes", city = "All", address = "Nationwide Outlets & Online", url = "https://shoeplanet.pk", isBrand = true, badge = "50% OFF"),
        Deal(shopName = "Insignia", title = "High Fashion Women Heels & Handbags Sale", discount = 35, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://insignia.pk", isBrand = true, badge = "35% OFF"),
        Deal(shopName = "Urban Sole", title = "Genuine Leather Formal & Casual Men Shoes Sale", discount = 30, category = "Shoes", city = "All", address = "Nationwide Stores & Online", url = "https://urbansole.com.pk", isBrand = true, badge = "30% OFF"),

        // Electronics (15+ Deals)
        Deal(shopName = "PriceOye", title = "Lowest Price Guaranteed on Smartphones & Earbuds!", discount = 35, category = "Electronics", city = "All", address = "Online Nationwide Shipping", url = "https://priceoye.pk", isBrand = true, badge = "BEST PRICE"),
        Deal(shopName = "Telemart", title = "Flash Sale on Laptops, Tablets & Smartwatches", discount = 30, category = "Electronics", city = "All", address = "Online & Stores Nationwide", url = "https://www.telemart.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Haier Pakistan", title = "Inverter AC, Refrigerator & Washing Machine Sale", discount = 25, category = "Electronics", city = "All", address = "Authorized Dealers & Online", url = "https://www.haier.com/pk", isBrand = true, badge = "INVERTER SALE"),
        Deal(shopName = "Dawlance", title = "Reliable Home Appliances Big Discount Offer", discount = 20, category = "Electronics", city = "All", address = "Authorized Dealers Nationwide", url = "https://www.dawlance.com.pk", isBrand = true, badge = "SPECIAL DISCOUNT"),
        Deal(shopName = "Samsung Pakistan", title = "Galaxy Smartphones & Smart TVs Trade-in Discounts", discount = 15, category = "Electronics", city = "All", address = "Flagship Stores & Online", url = "https://www.samsung.com/pk", isBrand = true, badge = "OFFICIAL OFFER"),
        Deal(shopName = "Kenwood", title = "Air Conditioners & Kitchen Appliances Discount", discount = 20, category = "Electronics", city = "All", address = "Nationwide Dealers & Online", url = "https://kenwoodpakistan.com", isBrand = true, badge = "SEASON DEAL"),
        Deal(shopName = "Ecostar", title = "Smart LED TVs & Appliances Grand Discount", discount = 25, category = "Electronics", city = "All", address = "Nationwide Stores & Online", url = "https://ecostar.com.pk", isBrand = true, badge = "25% OFF"),
        Deal(shopName = "Orient", title = "DC Inverter AC & Smart Refrigerator Mega Offer", discount = 30, category = "Electronics", city = "All", address = "Nationwide Dealers & Online", url = "https://orient.com.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Audionic", title = "Wireless Earbuds, Speakers & Power Banks Sale", discount = 40, category = "Electronics", city = "All", address = "Online & Stores Nationwide", url = "https://audionic.co", isBrand = true, badge = "AUDIO DEAL"),
        Deal(shopName = "TCL Pakistan", title = "4K UHD Smart QLED TVs Special Season Sale", discount = 25, category = "Electronics", city = "All", address = "Nationwide Outlets & Online", url = "https://www.tclpakistan.com", isBrand = true, badge = "TV OFFER"),

        // Grocery (10+ Deals)
        Deal(shopName = "Carrefour Pakistan", title = "Weekly Grocery, Fresh Food & Electronics Savings", discount = 20, category = "Grocery", city = "All", address = "Carrefour Stores & App", url = "https://www.carrefour.pk", isBrand = true, badge = "WEEKLY SAVINGS"),
        Deal(shopName = "Metro Cash & Carry", title = "Bulk Wholesale Grocery & Household Discount", discount = 25, category = "Grocery", city = "All", address = "Metro Wholesale Stores", url = "https://www.metro.pk", isBrand = true, badge = "WHOLESALE DEAL"),
        Deal(shopName = "Imtiaz Super Market", title = "Monthly Ration & Grocery Special Discount Offer", discount = 30, category = "Grocery", city = "All", address = "Imtiaz Super Markets Nationwide", url = "https://www.imtiaz.com.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "Naheed Superstore", title = "Imported Skincare, Grocery & Personal Care Sale", discount = 20, category = "Grocery", city = "All", address = "Naheed Outlets & Online", url = "https://www.naheed.pk", isBrand = true, badge = "SPECIAL SALE"),
        Deal(shopName = "Panda Mart", title = "15-Minute Instant Grocery Delivery Discount Coupons", discount = 25, category = "Grocery", city = "All", address = "Foodpanda App Nationwide", url = "https://www.foodpanda.pk", isBrand = true, badge = "INSTANT DELIVERY"),

        // Cosmetics (10+ Deals)
        Deal(shopName = "Saeed Ghani", title = "Natural Herbal Oils, Skincare & Henna Flat 30% Off", discount = 30, category = "Cosmetics", city = "All", address = "Nationwide Outlets & Online", url = "https://saeedghani.pk", isBrand = true, badge = "30% OFF"),
        Deal(shopName = "WB by Hemani", title = "Herbal Beauty Products, Perfumes & Skincare Sale", discount = 35, category = "Cosmetics", city = "All", address = "Nationwide Stores & Online", url = "https://wbhemani.com", isBrand = true, badge = "HERBAL BEAUTY"),
        Deal(shopName = "Luscious Cosmetics", title = "Lipsticks, Foundations & Makeup Palettes 40% Off", discount = 40, category = "Cosmetics", city = "All", address = "Online Nationwide Shipping", url = "https://iloveluscious.com", isBrand = true, badge = "MAKEUP SALE"),
        Deal(shopName = "Conatural", title = "Organic Hair Oils, Serums & Organic Skincare Sale", discount = 25, category = "Cosmetics", city = "All", address = "Nationwide Stores & Online", url = "https://conaturalonline.com", isBrand = true, badge = "ORGANIC SALE"),
        Deal(shopName = "Organic Traveller", title = "Vitamin C Serums & Sunscreen Bundles Discount", discount = 30, category = "Cosmetics", city = "All", address = "Online Nationwide Delivery", url = "https://organictraveller.pk", isBrand = true, badge = "30% OFF")
    )

    if (categoryFilter == "All" || categoryFilter == "City Promotions" || categoryFilter == "Fashion" || categoryFilter == "Furniture") {
        return allBrandDeals
    }
    return allBrandDeals.filter { it.category.equals(categoryFilter, ignoreCase = true) }
}

fun fetchGoogleCustomSearchDeals(categoryFilter: String = "All", countryCode: String = "PK", onResult: (List<Deal>) -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        val deals = getDynamicNationalBrandDeals(categoryFilter, countryCode)
        withContext(Dispatchers.Main) {
            onResult(deals)
        }
    }
}

// ==========================================
// DATA MODEL
// ==========================================

data class Deal(
    val id: String = UUID.randomUUID().toString(),
    val shopName: String = "",
    val title: String = "",
    val discount: Int = 20,
    val category: String = "Food",
    val city: String = "Sialkot",
    val address: String = "",
    val whatsappNumber: String = "923338705813",
    val imageBase64: String = "",
    val packageType: String = "1 Week Package (7 Days)",
    val expiryTimestamp: Long = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L),
    val isFlashSale: Boolean = false,
    val flashDurationHours: Int = 6,
    val isFreeTrialUsed: Boolean = false,
    val badge: String = "VERIFIED",
    val url: String = "https://www.facebook.com",
    val status: String = "active",
    val isLocalShop: Boolean = true,
    val distanceKm: Double = 1.1,
    val isBrand: Boolean = false,
    val brandLogoUrlOrBase64: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)

val INITIAL_DEALS_DATABASE = listOf(
    Deal(shopName = "Khaadi", title = "Winter Clearance Flat 50% Off on Fabric & Pret", discount = 50, category = "Clothes", city = "All", address = "Nationwide Stores", whatsappNumber = "923338705813", packageType = "Brand Partnership", expiryTimestamp = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L), isFlashSale = true, badge = "50% OFF", url = "https://www.khaadi.com", isBrand = true),
    Deal(shopName = "Sapphire", title = "Ready to Wear & Unstitched Intermix Sale", discount = 40, category = "Clothes", city = "All", address = "Nationwide Stores", whatsappNumber = "923338705813", packageType = "Brand Partnership", expiryTimestamp = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L), isFlashSale = false, badge = "40% OFF", url = "https://www.sapphireonline.pk", isBrand = true),
    Deal(shopName = "KFC", title = "Zinger Stacker & Krunch Burger Mega Combo!", discount = 30, category = "Food", city = "All", address = "Nationwide Outlets", whatsappNumber = "923338705813", packageType = "Brand Partnership", expiryTimestamp = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L), isFlashSale = true, badge = "HOT DEAL", url = "https://www.kfcpakistan.com/", isBrand = true),
    Deal(shopName = "Bata", title = "Footwear Clearance Flat 50% Off!", discount = 50, category = "Shoes", city = "All", address = "Nationwide Stores", whatsappNumber = "923338705813", packageType = "Brand Partnership", expiryTimestamp = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L), isFlashSale = false, badge = "50% OFF", url = "https://www.bata.pk/", isBrand = true),

    Deal(shopName = "Farhan Cloth House", title = "Local Khaddar & Boski Special Discount for Sialkot Residents", discount = 45, category = "Clothes", city = "Sialkot", address = "Paris Road Sialkot", whatsappNumber = "923338705813", packageType = "1 Month Package (30 Days)", expiryTimestamp = System.currentTimeMillis() + (15L * 24 * 60 * 60 * 1000L), isBrand = false, badge = "LOCAL SHOP", url = "https://www.facebook.com", isLocalShop = true, distanceKm = 0.3),
    Deal(shopName = "Bismillah Footwear", title = "Local Leather Shoes & Chappal Sale in Cantt Sialkot", discount = 40, category = "Shoes", city = "Sialkot", address = "Cantt Sialkot", whatsappNumber = "923338705813", packageType = "15 Days Package (15 Days)", expiryTimestamp = System.currentTimeMillis() + (10L * 24 * 60 * 60 * 1000L), isBrand = false, badge = "LOCAL SHOP", url = "https://www.facebook.com", isLocalShop = true, distanceKm = 0.4),
    Deal(shopName = "Sialkot Food Point", title = "Special Desi Murgh Chana & Naan Deal for Residents", discount = 50, category = "Food", city = "Sialkot", address = "Kashmir Road Sialkot", whatsappNumber = "923338705813", packageType = "1 Week Package (7 Days)", expiryTimestamp = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000L), isBrand = false, badge = "LOCAL SHOP", url = "https://www.facebook.com", isLocalShop = true, distanceKm = 0.2)
)

val countryList = listOf("Pakistan", "UAE", "UK", "USA", "Global")

val provinceMap = mapOf(
    "Pakistan" to listOf("Punjab", "Sindh", "KPK", "Balochistan", "Islamabad Capital Territory", "Gilgit-Baltistan", "AJK"),
    "UAE" to listOf("Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain"),
    "UK" to listOf("England", "Scotland", "Wales", "Northern Ireland"),
    "USA" to listOf("California", "New York", "Texas", "Florida", "Illinois"),
    "Global" to listOf("Worldwide")
)

val pakistanCitiesMap = mapOf(
    "Punjab" to listOf("Sialkot", "Lahore", "Faisalabad", "Rawalpindi", "Multan", "Gujranwala", "Bahawalpur", "Sargodha", "Gujrat", "Sahiwal", "Jhelum", "Rahim Yar Khan", "Sheikhupura", "Kasur", "Okara", "Chiniot", "Kamoke", "Hafizabad", "Sadiqabad", "Burewala", "Khanewal", "Muzaffargarh", "Mandi Bahauddin", "Toba Tek Singh", "Khanpur", "Dera Ghazi Khan"),
    "Sindh" to listOf("Karachi", "Hyderabad", "Sukkur", "Larkana", "Nawabshah", "Mirpur Khas", "Jacobabad", "Shikarpur", "Khairpur", "Dadu", "Tando Adam", "Ghotki", "Badin"),
    "KPK" to listOf("Peshawar", "Abbottabad", "Mardan", "Swat", "Nowshera", "Charsadda", "Bannu", "Kohat", "Dera Ismail Khan", "Mansehra", "Swabi", "Haripur"),
    "Balochistan" to listOf("Quetta", "Gwadar", "Turbat", "Khuzdar", "Sibi", "Loralai", "Zhob", "Chaman", "Kalat", "Panjgur"),
    "Islamabad Capital Territory" to listOf("Islamabad"),
    "Gilgit-Baltistan" to listOf("Gilgit", "Skardu", "Hunza", "Diamer", "Ghizer", "Astore", "Ghanche"),
    "AJK" to listOf("Muzaffarabad", "Mirpur", "Rawalakot", "Kotli", "Bhimber", "Hajira", "Bagh", "Poonch"),
    "Dubai" to listOf("Dubai City", "Deira", "Bur Dubai", "Jumeirah", "Downtown Dubai"),
    "Abu Dhabi" to listOf("Abu Dhabi City", "Al Ain", "Madinat Zayed"),
    "Sharjah" to listOf("Sharjah City", "Khor Fakkan", "Kalba"),
    "Ajman" to listOf("Ajman City"),
    "Ras Al Khaimah" to listOf("RAK City"),
    "Fujairah" to listOf("Fujairah City"),
    "Umm Al Quwain" to listOf("UAQ City"),
    "England" to listOf("London", "Manchester", "Birmingham", "Liverpool", "Leeds"),
    "Scotland" to listOf("Edinburgh", "Glasgow", "Aberdeen"),
    "Wales" to listOf("Cardiff", "Swansea"),
    "Northern Ireland" to listOf("Belfast", "Derry"),
    "California" to listOf("Los Angeles", "San Francisco", "San Diego", "San Jose", "Sacramento"),
    "New York" to listOf("New York City", "Buffalo", "Albany", "Rochester"),
    "Texas" to listOf("Houston", "Dallas", "Austin", "San Antonio", "Fort Worth"),
    "Florida" to listOf("Miami", "Orlando", "Tampa", "Jacksonville"),
    "Illinois" to listOf("Chicago", "Springfield", "Naperville"),
    "Worldwide" to listOf("Global / Online")
)

// ==========================================
// MATERIAL 3 THEME WITH SYSTEM TYPOGRAPHY
// ==========================================

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent {
            SaleAlertTheme {
                SaleAlertScreen()
            }
        }
    }
}

@Composable
fun SaleAlertTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = Color(0xFF1A56DB),
            secondary = Color(0xFFE02424),
            tertiary = Color(0xFFFACA15),
            background = Color(0xFF0F1115),
            surface = Color(0xFF181B21),
            onBackground = Color(0xFFE0E0E0),
            onSurface = Color(0xFFFFFFFF)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF1A56DB),
            secondary = Color(0xFFE02424),
            tertiary = Color(0xFFFACA15),
            background = Color(0xFFF9FAFB),
            surface = Color(0xFFFFFFFF),
            onBackground = Color(0xFF111827),
            onSurface = Color(0xFF111827)
        )
    }

    val typography = Typography(
        displayLarge = TextStyle(fontFamily = FontFamily.Default),
        displayMedium = TextStyle(fontFamily = FontFamily.Default),
        displaySmall = TextStyle(fontFamily = FontFamily.Default),
        headlineLarge = TextStyle(fontFamily = FontFamily.Default),
        headlineMedium = TextStyle(fontFamily = FontFamily.Default),
        headlineSmall = TextStyle(fontFamily = FontFamily.Default),
        titleLarge = TextStyle(fontFamily = FontFamily.Default),
        titleMedium = TextStyle(fontFamily = FontFamily.Default),
        titleSmall = TextStyle(fontFamily = FontFamily.Default),
        bodyLarge = TextStyle(fontFamily = FontFamily.Default),
        bodyMedium = TextStyle(fontFamily = FontFamily.Default),
        bodySmall = TextStyle(fontFamily = FontFamily.Default),
        labelLarge = TextStyle(fontFamily = FontFamily.Default),
        labelMedium = TextStyle(fontFamily = FontFamily.Default),
        labelSmall = TextStyle(fontFamily = FontFamily.Default)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        content = content
    )
}

// ==========================================
// MAIN SCREEN & REUSABLE COMPONENTS
// ==========================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SaleAlertScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedMainTab by remember { mutableStateOf(0) } // 0: Brand Sales, 1: Local Deals
    var selectedCategory by remember { mutableStateOf("All") }
    var currentCity by remember { mutableStateOf("Sialkot") }
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf("Latest") }
    var isScanning by remember { mutableStateOf(false) }
    var showPostDialog by remember { mutableStateOf(false) }
    var isPromoteSelected by remember { mutableStateOf(false) }
    var showLocationDisclosure by remember { mutableStateOf(true) }
    var userLat by remember { mutableStateOf<Double?>(null) }
    var userLng by remember { mutableStateOf<Double?>(null) }

    val dealsState = remember { mutableStateListOf<Deal>().apply { addAll(INITIAL_DEALS_DATABASE) } }
    val categories = listOf("All", "Food", "Clothes", "Shoes", "Electronics", "Grocery", "Cosmetics", "City Promotions")

    fun loadDeals() {
        val db = FirebaseFirestore.getInstance()
        db.collection("deals")
            .get()
            .addOnSuccessListener { snapshot ->
                val remoteDeals: List<Deal> = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(Deal::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }
                for (rd: Deal in remoteDeals) {
                    if (dealsState.none { it.id == rd.id || it.title == rd.title }) {
                        dealsState.add(0, rd)
                    }
                }
            }
            .addOnFailureListener {}
    }

    val userCountryCode = remember { getUserCountryCode(context) }

    // Auto-Trigger Search API on Load & Category Selection with 12h Offline Caching
    LaunchedEffect(selectedMainTab, selectedCategory) {
        if (selectedMainTab == 1 && userCountryCode != "PK") {
            return@LaunchedEffect
        }

        val db = FirebaseFirestore.getInstance()
        db.collection("deals")
            .get()
            .addOnSuccessListener { snapshot ->
                val remoteDeals: List<Deal> = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(Deal::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }
                for (rd: Deal in remoteDeals) {
                    if (dealsState.none { it.id == rd.id || it.title == rd.title }) {
                        dealsState.add(0, rd)
                    }
                }
            }

        db.collection("deals")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot != null) {
                    val remoteDeals: List<Deal> = snapshot.documents.mapNotNull { doc ->
                        try {
                            doc.toObject(Deal::class.java)?.copy(id = doc.id)
                        } catch (_: Exception) {
                            null
                        }
                    }
                    for (rd: Deal in remoteDeals) {
                        if (dealsState.none { it.id == rd.id || it.title == rd.title }) {
                            dealsState.add(0, rd)
                        }
                    }
                }
            }

        if (selectedMainTab == 0) {
            val cachedDeals = getCachedBrandDeals(context)
            if (!cachedDeals.isNullOrEmpty()) {
                for (cd in cachedDeals) {
                    if (dealsState.none { it.url == cd.url && it.title == cd.title }) {
                        dealsState.add(0, cd)
                    }
                }
            } else {
                fetchGoogleCustomSearchDeals(selectedCategory, userCountryCode) { apiDeals ->
                    if (apiDeals.isNotEmpty()) {
                        saveBrandDealsToCache(context, apiDeals)
                    }
                    for (ad in apiDeals) {
                        if (dealsState.none { it.url == ad.url && it.title == ad.title }) {
                            dealsState.add(0, ad)
                        }
                    }
                }
            }
        }
    }

    fun fetchGpsLocation() {
        isScanning = true
        try {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            ) {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    if (location != null) {
                        userLat = location.latitude
                        userLng = location.longitude
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                val geocoder = Geocoder(context, Locale.getDefault())
                                @Suppress("DEPRECATION")
                                val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                                if (!addresses.isNullOrEmpty()) {
                                    val city = addresses[0].locality ?: addresses[0].subAdminArea ?: "Sialkot"
                                    withContext(Dispatchers.Main) {
                                        currentCity = city
                                        isScanning = false
                                        Toast.makeText(context, "Location updated: $city", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    withContext(Dispatchers.Main) {
                                        isScanning = false
                                    }
                                }
                            } catch (_: Exception) {
                                withContext(Dispatchers.Main) {
                                    isScanning = false
                                }
                            }
                        }
                    } else {
                        isScanning = false
                        Toast.makeText(context, "GPS unavailable. Showing national deals.", Toast.LENGTH_SHORT).show()
                    }
                }.addOnFailureListener {
                    isScanning = false
                }
            } else {
                isScanning = false
            }
        } catch (_: Exception) {
            isScanning = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            fetchGpsLocation()
        }
    }

    if (showLocationDisclosure) {
        AlertDialog(
            onDismissRequest = { showLocationDisclosure = false },
            title = { Text("Location Permission", fontWeight = FontWeight.Bold) },
            text = { Text("Sale Alert uses your location to automatically display discounts, sales, and local shop offers available near you.") },
            confirmButton = {
                Button(
                    onClick = {
                        showLocationDisclosure = false
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Allow")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLocationDisclosure = false }) {
                    Text("Not Now", color = Color.Gray)
                }
            }
        )
    }

    val currentTime = System.currentTimeMillis()
    val validDeals = dealsState.filter { it.expiryTimestamp > currentTime && it.status == "active" }
    val userCoords = remember(currentCity) { getCityCoordinates(currentCity) }
    val activeUserLat = userLat ?: userCoords.first
    val activeUserLng = userLng ?: userCoords.second

    val filteredDeals = remember(selectedMainTab, selectedCategory, currentCity, searchQuery, sortOption, validDeals, activeUserLat, activeUserLng, userCountryCode) {
        val tabFiltered = if (selectedMainTab == 0) {
            validDeals.filter { deal ->
                deal.isBrand && (searchQuery.isBlank() || deal.shopName.contains(searchQuery, ignoreCase = true) || deal.title.contains(searchQuery, ignoreCase = true) || deal.category.contains(searchQuery, ignoreCase = true)) &&
                (selectedCategory == "All" || selectedCategory == "City Promotions" || deal.category.equals(selectedCategory, ignoreCase = true))
            }
        } else {
            if (userCountryCode != "PK") {
                emptyList()
            } else {
                validDeals.filter { deal ->
                    if (deal.isBrand) false
                    else {
                        val shopLat = if (deal.latitude != 0.0) deal.latitude else getCityCoordinates(deal.city).first
                        val shopLon = if (deal.longitude != 0.0) deal.longitude else getCityCoordinates(deal.city).second
                        val distance = calculateDistanceKm(activeUserLat, activeUserLng, shopLat, shopLon)
                        val isWithin30Km = distance <= 30.0
                        isWithin30Km && (searchQuery.isBlank() || deal.shopName.contains(searchQuery, ignoreCase = true) || deal.title.contains(searchQuery, ignoreCase = true) || deal.category.contains(searchQuery, ignoreCase = true))
                    }
                }
            }
        }

        when (sortOption) {
            "Highest Discount" -> tabFiltered.sortedByDescending { it.discount }
            "Nearest" -> tabFiltered.sortedBy { 
                if (it.isBrand) 0.0 
                else {
                    val sLat = if (it.latitude != 0.0) it.latitude else getCityCoordinates(it.city).first
                    val sLon = if (it.longitude != 0.0) it.longitude else getCityCoordinates(it.city).second
                    calculateDistanceKm(activeUserLat, activeUserLng, sLat, sLon)
                }
            }
            "Expiring Soon" -> tabFiltered.sortedBy { it.expiryTimestamp }
            else -> tabFiltered.sortedByDescending { it.expiryTimestamp } // Latest
        }
    }

    val tickerText = filteredDeals.joinToString("   🔥   ") { "${it.shopName}: ${it.title} [${it.badge}]" }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // UI Layout completely preserved as requested (Strict UI-Only rule adhered to)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 56.dp)
        ) {
            // 1. Top App Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Star, contentDescription = "Logo", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sale Alert",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Deals near $currentCity • Muhammad Farhan Iqbal",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    if (userCountryCode == "PK") {
                        OutlinedButton(
                            onClick = { 
                                isPromoteSelected = true
                                showPostDialog = true 
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isPromoteSelected || showPostDialog) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Promote", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "+ Promote Shop",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    } else {
                        Text(
                            text = "Local promotions available in PK",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            maxLines = 1
                        )
                    }
                }
            }

            // 2. Segmented Navigation TabRow
            TabRow(
                selectedTabIndex = selectedMainTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.height(44.dp)
            ) {
                Tab(
                    selected = selectedMainTab == 0,
                    onClick = { selectedMainTab = 0 },
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedMainTab == 0) MaterialTheme.colorScheme.primary else Color.Transparent)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Icon(
                            Icons.Default.ShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (selectedMainTab == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Brand Sales",
                            fontWeight = if (selectedMainTab == 0) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = if (selectedMainTab == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Tab(
                    selected = selectedMainTab == 1,
                    onClick = { selectedMainTab = 1 },
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedMainTab == 1) MaterialTheme.colorScheme.primary else Color.Transparent)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Icon(
                            Icons.Default.Place,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (selectedMainTab == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Local Deals",
                            fontWeight = if (selectedMainTab == 1) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = if (selectedMainTab == 1) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 3. Live Deal Ticker
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF111827)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Color(0xFFE02424),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "LIVE",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tickerText.ifBlank { "🔥 Explore top verified discount sales and promotions nationwide." },
                        color = Color.White,
                        fontSize = 11.sp,
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee(
                                iterations = Int.MAX_VALUE,
                                velocity = 40.dp
                            )
                    )
                }
            }

            // 4. Search Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.background
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (selectedMainTab == 0) "Search national brands & stores..." else "Search local city deals...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .shadow(1.dp, RoundedCornerShape(14.dp))
                )
            }

            // 5. Filter / Sort Chips
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.background
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Menu, contentDescription = "Sort", tint = Color.Gray, modifier = Modifier.size(14.dp))
                    val sortOptions = listOf("Latest", "Highest Discount", "Nearest", "Expiring Soon")
                    sortOptions.forEach { option ->
                        FilterChip(
                            selected = sortOption == option,
                            onClick = { sortOption = option },
                            label = { Text(option, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.White,
                                containerColor = MaterialTheme.colorScheme.surface,
                                labelColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            // 6. Category Chips
            if (selectedMainTab == 0) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ScrollableTabRow(
                        selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                        edgePadding = 12.dp,
                        containerColor = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.primary,
                        indicator = {}
                    ) {
                        categories.forEach { category ->
                            val isSelected = selectedCategory == category
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    searchQuery = ""
                                    selectedCategory = category
                                },
                                label = { Text(category, fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        modifier = Modifier.size(12.dp),
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.White,
                                    containerColor = MaterialTheme.colorScheme.surface,
                                    labelColor = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }
                }
            }

            // 7. Deals List Container with weight(1f)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedMainTab == 0) "Trending National Brand Sales" else "Active Local Deals in $currentCity",
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        if (selectedMainTab == 1) {
                            TextButton(onClick = { fetchGpsLocation() }, contentPadding = PaddingValues(4.dp)) {
                                Icon(Icons.Default.Place, contentDescription = "GPS", modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(if (isScanning) "Scanning..." else "Detect City", fontSize = 11.sp)
                            }
                        }
                    }
                }

                if (selectedMainTab == 1 && userCountryCode != "PK") {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    modifier = Modifier.size(56.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Place,
                                            contentDescription = "Location",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Local Shop Promotions",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Local shop promotions are currently available in Pakistan.",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else if (filteredDeals.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    modifier = Modifier.size(56.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = "Empty",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "No deals found",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (selectedMainTab == 0) "We couldn't find matching brand sales right now." else "No local offers available for $currentCity. Be the first to promote your shop!",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                                Button(
                                    onClick = { loadDeals() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Refresh Deals", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredDeals, key = { it.id }) { deal ->
                        DealCard(deal = deal)
                    }
                }
            }
        }

        if (showPostDialog) {
            MerchantPostSaleDialog(
                onDismiss = { 
                    showPostDialog = false
                    isPromoteSelected = false
                },
                onPublishSuccess = {
                    Toast.makeText(context, "Deal published successfully!", Toast.LENGTH_LONG).show()
                    loadDeals()
                }
            )
        }

        // 8. Bottom AdMob Banner Container
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .shadow(4.dp)
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                factory = { ctx ->
                    AdView(ctx).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = "ca-app-pub-3940256099942544/6300978111"
                        loadAd(AdRequest.Builder().build())
                    }
                }
            )
        }
    }
}

// ==========================================
// REUSABLE COMPONENTS & DIALOGS
// ==========================================

@Composable
fun MerchantPostSaleDialog(
    onDismiss: () -> Unit,
    onPublishSuccess: () -> Unit
) {
    val context = LocalContext.current
    var shopName by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var discountStr by remember { mutableStateOf("20") }
    var selectedCategory by remember { mutableStateOf("Food") }
    var city by remember { mutableStateOf("Sialkot") }
    var address by remember { mutableStateOf("") }
    var whatsappNumber by remember { mutableStateOf("") }
    var packageType by remember { mutableStateOf("30 Days Free Trial") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isPosting by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    val categories = listOf("Food", "Clothes", "Shoes", "Medicine", "Furniture", "Fashion", "Electronics", "Grocery")
    val packages = listOf(
        "30 Days Free Trial",
        "1 Week Package (7 Days) - Rs. 500",
        "15 Days Package (15 Days) - Rs. 900",
        "1 Month Package (30 Days) - Rs. 1,500"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Home, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Promote Your Shop", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("Shop / Brand Name") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Sale Title (e.g. Flat 50% Off)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = discountStr,
                    onValueChange = { discountStr = it },
                    label = { Text("Discount Percentage (e.g. 50)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("City (e.g. Sialkot)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Shop Address / Location") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = whatsappNumber,
                    onValueChange = { whatsappNumber = it },
                    label = { Text("WhatsApp Number (e.g. 923338705813)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Promotion Package:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                packages.forEach { pkg ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = packageType == pkg,
                            onClick = { packageType = pkg }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(pkg, fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = { imagePickerLauncher.launch("image/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (selectedImageUri == null) "Select Shop Image (Optional)" else "Image Attached Successfully")
                }

                if (packageType.startsWith("30 Days Free Trial")) {
                    Surface(
                        color = Color(0xFFFFF3E0),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🎁 30 Days Free Trial: 1 free trial per WhatsApp number.",
                            fontSize = 11.sp,
                            color = Color(0xFFE65100),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                } else {
                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("💳 Payment Recipient: Muhammad Farhan Iqbal", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF2E7D32))
                            Text("EasyPaisa / UPaisa: 03338705813", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (shopName.isNotBlank() && title.isNotBlank() && whatsappNumber.isNotBlank()) {
                        isPosting = true
                        val db = FirebaseFirestore.getInstance()

                        val imageBase64 = if (selectedImageUri != null) {
                            uriToBase64(context, selectedImageUri!!)
                        } else {
                            ""
                        }

                        val discountVal = discountStr.toIntOrNull() ?: 20
                        val durationDays = when {
                            packageType.contains("7 Days") -> 7L
                            packageType.contains("15 Days") -> 15L
                            else -> 30L
                        }
                        val expiryTime = System.currentTimeMillis() + (durationDays * 24L * 60L * 60L * 1000L)

                        val cityCoords = getCityCoordinates(city)
                        val newDeal = Deal(
                            shopName = shopName,
                            title = title,
                            discount = discountVal,
                            category = selectedCategory,
                            city = city,
                            address = address,
                            whatsappNumber = whatsappNumber,
                            imageBase64 = imageBase64,
                            packageType = packageType,
                            expiryTimestamp = expiryTime,
                            isFlashSale = packageType.contains("Free Trial"),
                            badge = if (discountVal >= 50) "50% OFF" else "$discountVal% OFF",
                            url = "https://www.facebook.com",
                            isLocalShop = true,
                            isBrand = false,
                            latitude = cityCoords.first,
                            longitude = cityCoords.second
                        )

                        if (packageType.startsWith("30 Days Free Trial")) {
                            db.collection("deals")
                                .whereEqualTo("whatsappNumber", whatsappNumber)
                                .whereEqualTo("packageType", "30 Days Free Trial")
                                .get()
                                .addOnSuccessListener { documents ->
                                    if (!documents.isEmpty) {
                                        isPosting = false
                                        Toast.makeText(context, "Free Trial already used for this number.", Toast.LENGTH_LONG).show()
                                    } else {
                                        db.collection("deals").add(newDeal)
                                            .addOnSuccessListener {
                                                isPosting = false
                                                onPublishSuccess()
                                                onDismiss()
                                            }
                                            .addOnFailureListener { e ->
                                                isPosting = false
                                                Toast.makeText(context, "Failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                            }
                                    }
                                }
                                .addOnFailureListener {
                                    db.collection("deals").add(newDeal)
                                        .addOnSuccessListener {
                                            isPosting = false
                                            onPublishSuccess()
                                            onDismiss()
                                        }
                                        .addOnFailureListener { e ->
                                            isPosting = false
                                            Toast.makeText(context, "Failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                        }
                                }
                        } else {
                            db.collection("deals").add(newDeal)
                                .addOnSuccessListener {
                                    isPosting = false
                                    onPublishSuccess()
                                    onDismiss()
                                }
                                .addOnFailureListener { e ->
                                    isPosting = false
                                    Toast.makeText(context, "Failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                }
                        }
                    } else {
                        Toast.makeText(context, "Please enter shop name, title, and WhatsApp number.", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = !isPosting,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (isPosting) "Publishing..." else "Publish Deal", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.Gray)
            }
        }
    )
}

// Flash Sale Countdown Timer Widget
@Composable
fun FlashSaleCountdownTimer(endTime: Long) {
    var timeLeft by remember { mutableStateOf(endTime - System.currentTimeMillis()) }

    LaunchedEffect(endTime) {
        while (true) {
            timeLeft = (endTime - System.currentTimeMillis()).coerceAtLeast(0L)
            delay(1000L)
        }
    }

    if (timeLeft <= 0) {
        Surface(
            color = Color(0xFFE0E0E0),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                text = "Deal Expired",
                color = Color.DarkGray,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
        return
    }

    val hours = (timeLeft / (1000 * 60 * 60)) % 24
    val minutes = (timeLeft / (1000 * 60)) % 60
    val seconds = (timeLeft / 1000) % 60

    val timeString = String.format(Locale.getDefault(), "%02d:%02d:%02d remaining", hours, minutes, seconds)

    Surface(
        color = Color(0xFFFFEBEE),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, Color(0xFFE02424))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFE02424), modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "🔥 Flash Sale • $timeString",
                color = Color(0xFFE02424),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

// Deal Card with 16:9 Ratio Image Box decoding base64ToBitmap()
@Composable
fun DealCard(deal: Deal) {
    val context = LocalContext.current
    var showReportDialog by remember { mutableStateOf(false) }
    var showCouponDialog by remember { mutableStateOf(false) }

    val sanitizedDealUrl = sanitizeUrl(deal.url)
    val isUrlValid = sanitizedDealUrl.isNotBlank() && isValidUrl(sanitizedDealUrl)

    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    val expiryStr = sdf.format(Date(deal.expiryTimestamp))

    val promoCode = remember(deal.id) { "SALE-${(100000..999999).random()}" }
    val decodedBitmap = rememberDecodedBitmap(deal.imageBase64)
    val brandDomain = extractDomain(deal.url, deal.shopName)
    val faviconBitmap = rememberFaviconBitmap(brandDomain)

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report Deal", fontWeight = FontWeight.Bold) },
            text = { Text("Report this deal for inappropriate content or expired status?") },
            confirmButton = {
                Button(
                    onClick = {
                        showReportDialog = false
                        Toast.makeText(context, "Deal reported. Admin will review.", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE02424))
                ) {
                    Text("Report")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    if (showCouponDialog) {
        AlertDialog(
            onDismissRequest = { showCouponDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Instant Deal Coupon", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Show this promo code at ${deal.shopName} counter to redeem your discount.", fontSize = 13.sp, color = Color.Gray, textAlign = TextAlign.Center)

                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("PROMO CODE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = promoCode, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color.LightGray),
                        modifier = Modifier.size(130.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Star, contentDescription = "QR", modifier = Modifier.size(60.dp), tint = Color.DarkGray)
                                Text("Scan at Counter", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                        }
                    }

                    Text("Offer: ${deal.title}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary, textAlign = TextAlign.Center)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showCouponDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // 16:9 Ratio Image Box rendering decodedBitmap or Favicon logo
            if (decodedBitmap != null) {
                Image(
                    bitmap = decodedBitmap.asImageBitmap(),
                    contentDescription = "Deal Image",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            } else if (faviconBitmap != null) {
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                bitmap = faviconBitmap.asImageBitmap(),
                                contentDescription = "Brand Favicon",
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(deal.shopName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(deal.shopName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // Top Row: Brand / Shop Name & Prominent Discount Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = deal.shopName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color(0xFFE02424),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${deal.discount}% OFF",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = { showReportDialog = true },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.Gray, modifier = Modifier.size(15.dp))
                    }
                }
            }

            // Deal Title
            Text(
                text = deal.title,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (deal.address.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${deal.address} • ${deal.distanceKm} km away",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (!deal.isBrand && deal.isFlashSale) {
                FlashSaleCountdownTimer(endTime = deal.expiryTimestamp)
            }

            // Category & Expiry (Only show expiry for local deals or verified end dates, never for web-fetched brand sales)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${deal.category} • Verified Offer",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                if (!deal.isBrand) {
                    Text(
                        text = "Expires: $expiryStr",
                        color = Color(0xFFE02424),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Action Buttons Row (National Brand Sales: Website only; Local Deals: Get Coupon, WhatsApp, Website)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!deal.isBrand) {
                    // Primary Action: Get Coupon (Local Deals only)
                    Button(
                        onClick = { showCouponDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.3f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "Get Coupon", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    // Secondary Action: WhatsApp (Local Deals only)
                    Button(
                        onClick = {
                            val rawNum = deal.whatsappNumber.replace(Regex("[^0-9]"), "")
                            val waNumber = when {
                                rawNum.startsWith("03") -> "92" + rawNum.substring(1)
                                rawNum.startsWith("92") -> rawNum
                                rawNum.startsWith("3") && rawNum.length == 10 -> "92$rawNum"
                                rawNum.isNotBlank() -> rawNum
                                else -> "923338705813"
                            }
                            val message = "Hi, I want to claim this deal: '${deal.title}' at '${deal.shopName}' via Sale Alert app."
                            val whatsappUrl = "https://wa.me/$waNumber?text=${Uri.encode(message)}"
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(whatsappUrl))
                            try {
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }

                // Visit Website / View Deal Button (National Brand Sales displays ONLY this button)
                OutlinedButton(
                    onClick = {
                        if (isUrlValid) {
                            try {
                                val customTabsIntent = CustomTabsIntent.Builder().build()
                                customTabsIntent.launchUrl(context, Uri.parse(sanitizedDealUrl))
                            } catch (_: ActivityNotFoundException) {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(sanitizedDealUrl))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Unable to open link", Toast.LENGTH_SHORT).show()
                                }
                            } catch (_: Exception) {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(sanitizedDealUrl))
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Unable to open link", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            Toast.makeText(context, "Invalid website link", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = isUrlValid,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(if (deal.isBrand) 1f else 0.9f),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text(text = if (deal.isBrand) "Visit Website" else "Website", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}
